new window.VLibras.Widget('https://vlibras.gov.br/app');

function toggleMenu() {
  const sidebar = document.getElementById('sidebar');
  const footerIcons = document.getElementById('footer-icons');

  sidebar.classList.toggle('open');
  footerIcons.classList.toggle('horizontal');
}

function sendMessage() {
  const input = document.getElementById('userInput');
  const message = input.value.trim();
  if (message) {
    const messages = document.getElementById('messages');
    const userMessage = document.createElement('div');
    userMessage.className = 'message user';
    userMessage.innerHTML = `<div class="text">${message}</div>`;
    messages.appendChild(userMessage);
    input.value = '';
    messages.scrollTop = messages.scrollHeight;
  }
}

function handleSettingsClick() {
  alert('Abrindo configurações...');
}

function handleMoreClick() {
  alert('Abrindo mais opções...');
}

function handleLanguageChange() {
  alert('Trocando idioma entre Português e Inglês!');
}

function handleProfileClick() {
  alert('Abrindo opções do perfil...');
}
