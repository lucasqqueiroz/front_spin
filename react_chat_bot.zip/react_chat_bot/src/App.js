import React from 'react';
import './style.css';
import './style1.css';

function App() {
  const toggleMenu = () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
  };

  const handleLanguageChange = () => {
    console.log('Mudar idioma');
  };

  const handleMoreClick = () => {
    console.log('Adicionar novo item');
  };

  const handleProfileClick = () => {
    console.log('Abrir perfil do usuário');
  };

  const handleSettingsClick = () => {
    console.log('Abrir configurações');
  };

  const sendMessage = () => {
    const userInput = document.getElementById('userInput').value;
    console.log('Mensagem enviada:', userInput);
  };

  return (
    <div className="container-principal">
      {/* Menu lateral */}
      <div className="sidebar" id="sidebar">
        <button
          aria-label="Abrir ou fechar menu lateral"
          className="toggle-btn"
          onClick={toggleMenu}
        >
          ☰
        </button>
        {/* Ícones no rodapé do menu */}
        <div className="footer-icons" id="footer-icons">
          <button
            aria-label="Abrir site Spin Engenharia"
            onClick={() => window.open('https://spinengenharia.com.br/', '_blank')}
          >
            <img alt="Site Spin Engenharia" src="imagem/icone_spin,png.png" />
          </button>
          <a href="pagina ajuda/index-ajuda.html">
            <button
              aria-label="Abrir página de ajuda"
              onClick={() => (window.location.href = 'ajuda.html')}
            >
              <img alt="Ajuda Spindle" src="imagem/icone_ajuda.jpeg" />
            </button>
          </a>
        </div>
      </div>

      {/* Ícones fixos */}
      <div
        aria-label="Mudar idioma"
        className="icon-fixed language-icon"
        onClick={handleLanguageChange}
      >
        <i className="fas fa-language"></i>
      </div>
      <div className="icon-fixed accessibility-icon">
        <div className="enabled" vw="">
          <div className="active" vw-access-button=""></div>
          <div vw-plugin-wrapper="">
            <div className="vw-plugin-top-wrapper"></div>
          </div>
        </div>
      </div>

      {/* Conteúdo principal */}
      <div className="main-content">
        <div className="header">
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <div
              aria-label="Adicionar novo item"
              className="add-icon-left"
              onClick={handleMoreClick}
            >
              +
            </div>
            <img
              alt="Logotipo Spindle"
              className="avatar spindle-logo"
              src="imagem/spindle_bot.png"
            />
          </div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <button
              aria-label="Abrir perfil do usuário"
              className="profile-container"
              onClick={handleProfileClick}
            >
              <img alt="Foto do perfil de Joaquim" src="imagem/foto_perfil.jfif" />
              <span>Joaquim</span>
            </button>
            <span
              aria-label="Abrir configurações"
              className="settings-icon"
              onClick={handleSettingsClick}
            >
              <i className="fas fa-cog"></i>
            </span>
          </div>
        </div>

        <div className="chat-container">
          <div aria-live="polite" className="messages" id="messages">
            <div className="message bot">
              <img
                alt="Spindle"
                className="avatar"
                src="imagem/icone_chat_spindle.png"
              />
              <div className="text">
                Olá, sou a Spindle, assistente virtual. Como posso te ajudar?
              </div>
            </div>
            <div className="message user">
              <div className="text">Oi, Spindle! Pode me ajudar a criar um cronograma?</div>
            </div>
            <div className="message bot">
              <img
                alt="Spindle"
                className="avatar"
                src="imagem/icone_chat_spindle.png"
              />
              <div className="text">
                Claro! Aqui estão algumas dicas de produtividade para começar...
              </div>
            </div>
          </div>
          <div className="input-area">
            <span aria-label="Anexar arquivo" className="attachment-icon">
              <i className="fas fa-paperclip"></i>
            </span>
            <span aria-label="Gravar áudio" className="microphone-icon">
              <i className="fas fa-microphone"></i>
            </span>
            <input
              aria-label="Digite sua mensagem"
              id="userInput"
              placeholder="Pergunte ao Spindle..."
              type="text"
            />
            <span
              aria-label="Enviar mensagem"
              className="send-icon"
              onClick={sendMessage}
            >
              <i className="fas fa-paper-plane"></i>
            </span>
          </div>
        </div>
      </div>

      {/* Plugins e scripts */}
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script src="react1.js"></script>
    </div>
  );
}

export default App;
